# BLAME Storefront

Premium audio production tools, sample packs, and studio rental — built on [Medusa](https://medusajs.com) + [Next.js 15](https://nextjs.org).

---

## Stack

| Layer | Tech |
|---|---|
| Framework | Next.js 15, App Router, Server Components |
| Commerce | Medusa v2 |
| Styling | Tailwind CSS + custom CSS design system |
| Fonts | Syne (display), Space Mono (mono), DM Sans (body) |
| Payments | Stripe (via Medusa Stripe module) |

## Brand Colors

| Token | Hex | Usage |
|---|---|---|
| `blame-teal` | `#006064` | Primary accent, buttons, borders |
| `blame-teal-light` | `#B2DFDB` | Text highlights, prices, tags |
| `blame-neutral` | `#E0E0E0` | Body text, icons |
| `blame-black` | `#0A0A0A` | Page background |

---

## Pages

| Route | File | Description |
|---|---|---|
| `/` | `app/[cc]/(main)/page.tsx` | Homepage — hero, categories, products, rental |
| `/store` | `app/[cc]/(main)/store/page.tsx` | Product catalogue with filters |
| `/products/[handle]` | `app/[cc]/(main)/products/[handle]/page.tsx` | Product detail + audio preview |
| `/rental` | `app/[cc]/(main)/rental/page.tsx` | Studio & gear rental |
| `/cart` | `app/[cc]/(main)/cart/page.tsx` | Cart with coupon |
| `/downloads` | `app/[cc]/(main)/downloads/page.tsx` | Digital purchase library |
| `/about` | `app/[cc]/(main)/about/page.tsx` | Company page |
| `/account/login` | `app/[cc]/(main)/account/login/page.tsx` | Sign in |
| `/account/register` | `app/[cc]/(main)/account/register/page.tsx` | Create account |

---

## Quick Start

```bash
# 1. Clone and install
cd storefront
yarn install

# 2. Configure environment
cp .env.template .env.local
# → Set MEDUSA_BACKEND_URL and NEXT_PUBLIC_MEDUSA_PUBLISHABLE_KEY

# 3. Start dev server
yarn dev
# → http://localhost:8000
```

### Prerequisites

- Node.js v20+ LTS
- Medusa v2 backend running on port 9000
- At least one Region created in Medusa Admin

---

## Medusa Modules Used

### Digital Products
From [medusajs/examples/digital-products](https://github.com/medusajs/examples/tree/main/digital-products).

Install in your Medusa backend:
```bash
# In your Medusa backend:
yarn add @medusajs/digital-product
```

Configure in `medusa-config.js`:
```js
modules: [
  {
    resolve: "@medusajs/digital-product",
  }
]
```

Download links are served from `/store/digital-products/download?order_id=XXX` after successful payment.

### Rental / Subscriptions
For studio and gear rental functionality:
```bash
yarn add @medusajs/subscription
```

Configure time-based billing and availability in Medusa Admin.

---

## Connecting to Medusa API

All API calls live in `src/lib/data/index.ts`. Replace mock data in page components with these helpers:

```tsx
// In a Server Component:
import { listProducts, getRegion } from "@/lib/data"

export default async function StorePage({ params }) {
  const region = await getRegion(params.countryCode)
  const { products } = await listProducts({ regionId: region.id, limit: 12 })
  return <ProductGrid products={products} />
}
```

---

## Key Design Decisions

- **countryCode routing**: All pages live under `/[countryCode]/` for multi-region support
- **Server Components first**: Data fetching happens on the server; only interactive UI is `"use client"`
- **Mock data**: All pages ship with realistic mock data so the UI works without a backend
- **CSS variables**: Design tokens defined in `globals.css`, mirrored in `tailwind.config.js`

---

## Digital Products Flow

```
1. Customer adds digital product to cart
2. Checkout via Stripe
3. On payment_captured webhook → Medusa creates download tokens
4. Customer sees download links in /downloads (from Orders API)
5. Download tokens expire after N uses (configurable)
```

---

## Studio Rental Flow

```
1. Customer browses /rental → selects studio + dates
2. Booking creates a Medusa order with rental metadata
3. Confirmation email sent via Medusa notifications
4. Day-of: Access code delivered via email/SMS
```
